package com.pacrush.auto

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class Detection(
    val inGame: Boolean,
    val pac: DoubleArray?,
    val orb: DoubleArray?,
    val bars: List<DoubleArray>
)

/**
 * Colour-agnostic detection at half resolution (360 wide). Background subtraction + blob size.
 * Output coordinates are in reference px (x2).
 */
class Vision(bgIn: ByteArray, private val w: Int, private val h: Int) {
    companion object { const val BG_W = 360; const val BG_H = 800 }

    private val bg: ByteArray
    private val n = w * h
    private val mask = BooleanArray(n)
    private val dil = BooleanArray(n)
    private val stack = IntArray(n)
    private val maskIdx = IntArray(n)
    private val ring: IntArray

    init {
        bg = if (h == BG_H) bgIn else {
            val out = ByteArray(w * h * 3)
            for (y in 0 until h) {
                val sy = min(BG_H - 1, y * BG_H / h)
                System.arraycopy(bgIn, sy * BG_W * 3, out, y * w * 3, w * 3)
            }
            out
        }
        val l = ArrayList<Int>()
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val d = hypot(x * 2.0 - C.RING_CX, y * 2.0 - C.RING_CY)
                if (d > C.RING_R - 50 && d < C.RING_R + 50) l.add(y * w + x)
                x += 2
            }
            y += 2
        }
        ring = l.toIntArray()
    }

    private fun maxDiff(px: ByteArray, i: Int): Int {
        val o = i * 4
        val b = i * 3
        val dr = abs((px[o].toInt() and 255) - (bg[b].toInt() and 255))
        val dg = abs((px[o + 1].toInt() and 255) - (bg[b + 1].toInt() and 255))
        val db = abs((px[o + 2].toInt() and 255) - (bg[b + 2].toInt() and 255))
        return max(dr, max(dg, db))
    }

    fun process(px: ByteArray): Detection {
        // menu / game-over screens differ strongly from the in-game background
        val hist = IntArray(256)
        for (i in ring) hist[maxDiff(px, i)]++
        var acc = 0
        var med = 0
        val half = ring.size / 2
        for (v in 0..255) { acc += hist[v]; if (acc > half) { med = v; break } }
        if (med >= 18) return Detection(false, null, null, emptyList())

        java.util.Arrays.fill(mask, false)
        java.util.Arrays.fill(dil, false)
        var mc = 0
        for (i in 0 until n) {
            if (maxDiff(px, i) <= 60) continue
            val o = i * 4
            val r = px[o].toInt() and 255
            val g = px[o + 1].toInt() and 255
            val b = px[o + 2].toInt() and 255
            val mx = max(r, max(g, b))
            val mn = min(r, min(g, b))
            val sat = if (mx == 0) 0 else (mx - mn) * 255 / mx
            if (sat > 70 && mx > 90) { mask[i] = true; maskIdx[mc++] = i }
        }
        for (k in 0 until mc) {
            val p = maskIdx[k]
            val x = p % w
            val y = p / w
            for (dy in -1..1) for (dx in -1..1) {
                val xx = x + dx
                val yy = y + dy
                if (xx in 0 until w && yy in 0 until h) dil[yy * w + xx] = true
            }
        }
        var pac: DoubleArray? = null
        var orb: DoubleArray? = null
        val bars = ArrayList<DoubleArray>()
        for (k in 0 until mc) {
            val s0 = maskIdx[k]
            if (!dil[s0]) continue
            var sp = 0
            stack[sp++] = s0
            dil[s0] = false
            var minX = Int.MAX_VALUE; var maxX = -1; var minY = Int.MAX_VALUE; var maxY = -1
            var cnt = 0; var sx = 0.0; var sy = 0.0
            while (sp > 0) {
                val p = stack[--sp]
                val x = p % w
                val y = p / w
                if (mask[p]) {
                    cnt++; sx += x; sy += y
                    if (x < minX) minX = x; if (x > maxX) maxX = x
                    if (y < minY) minY = y; if (y > maxY) maxY = y
                }
                for (dy in -1..1) for (dx in -1..1) {
                    val xx = x + dx
                    val yy = y + dy
                    if (xx in 0 until w && yy in 0 until h) {
                        val q = yy * w + xx
                        if (dil[q]) { dil[q] = false; stack[sp++] = q }
                    }
                }
            }
            if (cnt < 30) continue
            val bw = maxX - minX + 1
            val bh = maxY - minY + 1
            var cx = sx / cnt
            var cy = sy / cnt
            if (bw >= 50 && bh <= 31 && bw.toDouble() / bh > 2.0) {
                if (minY <= 0 && bh < 17.5) cy = (minY + bh) - 10.25
                else if (maxY >= h - 1 && bh < 17.5) cy = minY + 10.25
                bars.add(doubleArrayOf(cx * 2, cy * 2))
            } else if (bw in 29..42 && bh in 29..42) {
                if (nearRing(cx * 2, cy * 2)) pac = doubleArrayOf(cx * 2, cy * 2)
            } else if (bw in 19..28 && bh in 19..28) {
                if (nearRing(cx * 2, cy * 2)) orb = doubleArrayOf(cx * 2, cy * 2)
            }
        }
        return Detection(true, pac, orb, bars)
    }

    private fun nearRing(x: Double, y: Double) =
        abs(hypot(x - C.RING_CX, y - C.RING_CY) - C.RING_R) < 40
}
