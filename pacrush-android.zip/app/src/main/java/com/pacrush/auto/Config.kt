package com.pacrush.auto

/** Reference pixels: a 720-wide frame (same numbers as the Python version). */
object C {
    const val RING_CX = 359.8
    const val RING_CY = 847.4
    const val RING_R = 185.3
    const val BAR_W = 126.0
    const val BAR_H = 41.0
    const val PAC_HIT = 29.0
    const val MARGIN = 9.0
    const val PAC_OMEGA = 105.0
    const val BAR_VY = 250.0
    const val MIN_TAP_GAP = 0.12
    const val HORIZON = 2.0
    const val ORB_TOL = 15.0
    // fractions of the screen
    const val TAP_X = 0.50
    const val TAP_Y = 0.55
    const val RESTART_X = 0.35
    const val RESTART_Y = 0.74
}
