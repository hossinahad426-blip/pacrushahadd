package com.pacrush.auto

import android.util.Log
import java.io.File
import kotlin.math.max

/** Game loop logic: menu handling, pending taps, planning, death log. */
class Brain(
    private val vision: Vision,
    private val planner: Planner,
    private val tapFrac: (Double, Double) -> Unit,
    private val logDir: File?
) {
    private var tracker = Tracker()
    private val pending = ArrayList<DoubleArray>()      // [applyTime, directionWhenTapped]
    private var lastTap = -9.0
    private var gameT0 = -1.0
    private var wasIn = false
    private var menuTapT = -9.0
    private var menuToggle = 0
    private var lastInGame = -1e9
    private var games = 0
    private val trace = ArrayDeque<String>()

    private fun reset() {
        tracker = Tracker()
        pending.clear()
        lastTap = -9.0
        wasIn = false
    }

    private fun doTap(t: Double) {
        tapFrac(C.TAP_X, C.TAP_Y)
        lastTap = t
        pending.add(doubleArrayOf(t + planner.latency, tracker.direction.toDouble()))
    }

    fun step(t: Double, px: ByteArray) {
        val det = vision.process(px)
        if (!det.inGame) {
            if (wasIn) { dumpDeath(); reset() }
            // after a game ends: press replay / play for up to 25 s (never taps in other apps for long)
            if (t - lastInGame < 25.0 && t - menuTapT > 1.0) {
                if (menuToggle % 2 == 0) tapFrac(C.RESTART_X, C.RESTART_Y) else tapFrac(C.TAP_X, C.TAP_Y)
                menuToggle++
                menuTapT = t
            }
            return
        }
        lastInGame = t
        if (!wasIn) { wasIn = true; gameT0 = t; games++ }
        val w = tracker.update(t, det)
        pending.removeAll { t >= it[0] + 0.5 ||
                (t > it[0] + 0.05 && w.moving && w.direction.toDouble() != it[1] && it[1] != 0.0) }
        if (w.pacAngle == null) return
        if (!w.moving && w.bars.isEmpty() && t - gameT0 > 0.5 && t - lastTap > 1.0) {
            doTap(t)                                    // pac waits for the first tap
            return
        }
        val r = planner.plan(w, t - lastTap, pending.map { max(it[0] - t, 0.0) })
        if (r.tap) doTap(t)
        trace.addLast("%.3f ang=%.1f dir=%d orb=%s bars=%s plan=(%d,%d) surv=%.2f tap=%b".format(
            t, w.pacAngle, w.direction, w.orbAngle?.let { "%.1f".format(it) } ?: "-",
            w.bars.joinToString(",") { "(%d,%d,%d)".format(it.x.toInt(), it.y.toInt(), it.vy.toInt()) },
            r.first, r.second, r.surv, r.tap))
        if (trace.size > 120) trace.removeFirst()
    }

    private fun dumpDeath() {
        try {
            val f = File(logDir, "death_${System.currentTimeMillis()}.txt")
            f.writeText(trace.joinToString("\n"))
            Log.i("PacRush", "game $games ended, trace -> ${f.absolutePath}")
        } catch (e: Exception) {
            Log.e("PacRush", "log failed", e)
        }
    }
}
