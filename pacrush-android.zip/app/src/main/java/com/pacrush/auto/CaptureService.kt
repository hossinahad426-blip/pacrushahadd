package com.pacrush.auto

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager

class CaptureService : Service() {
    companion object { const val ACTION_STOP = "com.pacrush.auto.STOP" }

    private var mp: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        startFg()
        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mgr.getMediaProjection(code, data)
        mp = proj
        thread = HandlerThread("pacrush-cap").also { it.start() }
        val handler = Handler(thread!!.looper)
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        val w = Vision.BG_W
        val h = Math.round(w.toDouble() * sh / sw).toInt()

        val bg = assets.open("bg.raw").readBytes()
        val lat = getSharedPreferences("p", 0).getFloat("lat", 0.10f).toDouble()
        val brain = Brain(Vision(bg, w, h), Planner(lat), { fx, fy ->
            TapService.inst?.tap((fx * sw).toFloat(), (fy * sh).toFloat())
        }, getExternalFilesDir(null))

        val frame = ByteArray(w * h * 4)
        val rd = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = rd
        rd.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage()
            if (img != null) {
                try {
                    val pl = img.planes[0]
                    val buf = pl.buffer
                    val rs = pl.rowStride
                    if (rs == w * 4) buf.get(frame, 0, w * 4 * h)
                    else for (y in 0 until h) { buf.position(y * rs); buf.get(frame, y * w * 4, w * 4) }
                    brain.step(SystemClock.elapsedRealtimeNanos() / 1e9, frame)
                } catch (e: Exception) {
                    Log.e("PacRush", "frame error", e)
                } finally {
                    img.close()
                }
            }
        }, handler)
        vd = proj.createVirtualDisplay("pacrush", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, handler)
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("pacrush", "PacRush Auto", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0,
            Intent(this, CaptureService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, "pacrush")
            .setContentTitle("PacRush Auto চলছে")
            .setContentText("বন্ধ করতে Stop চাপুন")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(android.R.drawable.ic_delete, "Stop", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    override fun onDestroy() {
        try { vd?.release(); reader?.close(); mp?.stop(); thread?.quitSafely() } catch (_: Exception) {}
        super.onDestroy()
    }
}
