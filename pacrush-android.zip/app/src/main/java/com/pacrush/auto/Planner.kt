package com.pacrush.auto

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

class PlanResult(val tap: Boolean, val first: Int, val second: Int, val surv: Double)

/** Scores every "no tap / 1 tap / 2 taps" plan against a (time x angle) danger map. */
class Planner(val latency: Double) {
    private val dt = 0.04
    private val T = Math.round(C.HORIZON / dt).toInt()
    private val NA = 720
    private val lat = ceil(latency / dt - 1e-9).toInt()
    private val minGap = max(2, Math.round(C.MIN_TAP_GAP / dt).toInt())
    private val px = DoubleArray(NA)
    private val py = DoubleArray(NA)
    private val firstFlip: IntArray
    private val secondFlip: IntArray

    init {
        for (a in 0 until NA) {
            val rad = Math.toRadians(a * 0.5 - 180.0)
            px[a] = C.RING_CX + C.RING_R * cos(rad)
            py[a] = C.RING_CY + C.RING_R * sin(rad)
        }
        val f = ArrayList<Int>()
        val s = ArrayList<Int>()
        f.add(-1); s.add(-1)
        for (i in lat until T) { f.add(i); s.add(-1) }
        for (i in lat until T) for (j in lat until T) if (j >= i + minGap) { f.add(i); s.add(j) }
        firstFlip = f.toIntArray()
        secondFlip = s.toIntArray()
    }

    private fun danger(bars: List<Bar>, margin: Double): BooleanArray {
        val d = BooleanArray(T * NA)
        val rr = (C.PAC_HIT + margin) * (C.PAC_HIT + margin)
        val hw = C.BAR_W / 2
        val hh = C.BAR_H / 2
        for (k in 0 until T) {
            val t = (k + 1) * dt
            for (b in bars) {
                val by = b.y + b.vy * t
                if (by < -80 || by > 1700) continue
                for (a in 0 until NA) {
                    val dx = max(abs(px[a] - b.x) - hw, 0.0)
                    val dy = max(abs(py[a] - by) - hh, 0.0)
                    if (dx * dx + dy * dy < rr) d[k * NA + a] = true
                }
            }
        }
        return d
    }

    fun plan(w: World, sinceLast: Double, pending: List<Double>): PlanResult {
        val pa = w.pacAngle ?: return PlanResult(false, -1, -1, 0.0)
        val d0 = if (w.direction == 0) 1 else w.direction
        val om = w.omega
        val step = om * dt
        val base = IntArray(T) { 1 }
        for (r in pending) {
            val s = max(0, Math.round(r / dt).toInt())
            for (k in s until T) base[k] = -base[k]
        }
        val strict = danger(w.bars, C.MARGIN)
        val loose = danger(w.bars, 0.0)
        val H = T * dt
        val need = ceil(max(0.0, C.MIN_TAP_GAP - sinceLast) / dt - 1e-9).toInt()
        val orb = w.orbAngle
        var best = -1
        var bestScore = -1e18
        var bestSurv = 0.0
        for (p in firstFlip.indices) {
            val f1 = firstFlip[p]
            val f2 = secondFlip[p]
            if (f1 >= 0 && need > 0 && f1 - lat < need) continue
            var cum = 0.0
            var sl = T
            var ss = T
            var tOrb = -1
            var lastDiff = 0.0
            var parity = 1
            for (k in 0 until T) {
                if (k == f1 || k == f2) parity = -parity
                cum += parity * base[k]
                val path = pa + d0 * step * cum
                val m = (((path + 180.0) % 360.0) + 360.0) % 360.0
                val idx = Math.rint(m / 0.5).toInt() % NA
                if (sl == T && loose[k * NA + idx]) sl = k
                if (ss == T && strict[k * NA + idx]) ss = k
                if (orb != null) {
                    val df = abs((((path - orb + 180.0) % 360.0) + 360.0) % 360.0 - 180.0)
                    lastDiff = df
                    if (tOrb < 0 && df < C.ORB_TOL) tOrb = k
                }
            }
            val sLoose = sl * dt
            val sStrict = ss * dt
            val tFirst = if (orb == null) 0.0
            else if (tOrb >= 0) tOrb * dt else H + lastDiff / max(om, 1.0)
            val nf = (if (f1 >= 0) 1 else 0) + (if (f2 >= 0) 1 else 0)
            val safe = sLoose >= H && sStrict >= H
            val score = 100 * sLoose + 40 * sStrict - 0.6 * nf - (if (safe) 3.0 else 0.1) * tFirst
            if (score > bestScore) { bestScore = score; best = p; bestSurv = sLoose }
        }
        if (best < 0) return PlanResult(false, -1, -1, 0.0)
        val f1 = firstFlip[best]
        val tap = f1 >= 0 && f1 <= lat + 1 && sinceLast >= C.MIN_TAP_GAP
        return PlanResult(tap, f1, secondFlip[best], bestSurv)
    }
}
