package com.pacrush.auto

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var lat: EditText

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(48, 96, 48, 48)

        val info = TextView(this)
        info.textSize = 16f
        info.text = "PacRush Auto\n\n" +
            "১) নিচের বোতাম চেপে অ্যাক্সেসিবিলিটিতে \"PacRush Auto\" চালু করুন (ট্যাপ পাঠানোর জন্য)।\n" +
            "২) Start চাপুন, স্ক্রিন-ক্যাপচারের অনুমতি দিন।\n" +
            "৩) Pac Rush গেম খুলে Tap to Play চাপুন। বাকিটা বট করবে।\n" +
            "বন্ধ করতে নোটিফিকেশনের Stop চাপুন।\n\n" +
            "ট্যাপ ল্যাটেন্সি (সেকেন্ড):"
        box.addView(info)

        lat = EditText(this)
        lat.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        lat.setText(getSharedPreferences("p", 0).getFloat("lat", 0.10f).toString())
        box.addView(lat)

        val acc = Button(this)
        acc.text = "১) অ্যাক্সেসিবিলিটি সেটিংস খুলুন"
        acc.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        box.addView(acc)

        val start = Button(this)
        start.text = "২) Start"
        start.setOnClickListener {
            if (TapService.inst == null) {
                Toast.makeText(this, "আগে অ্যাক্সেসিবিলিটি চালু করুন", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val v = lat.text.toString().toFloatOrNull() ?: 0.10f
            getSharedPreferences("p", 0).edit().putFloat("lat", v).apply()
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mgr.createScreenCaptureIntent(), 1)
        }
        box.addView(start)
        setContentView(box)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java).putExtra("code", resultCode).putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
