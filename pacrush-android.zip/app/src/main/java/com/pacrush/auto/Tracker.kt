package com.pacrush.auto

import kotlin.math.abs
import kotlin.math.atan2

fun wrap(a: Double): Double = (((a + 180.0) % 360.0) + 360.0) % 360.0 - 180.0

class Bar(val x: Double, val y: Double, val vy: Double)

class World(
    val t: Double,
    val pacAngle: Double?,
    val direction: Int,
    val omega: Double,
    val orbAngle: Double?,
    val bars: List<Bar>,
    val moving: Boolean
)

class Tracker {
    private class Track(var x: Double) {
        val hist = ArrayDeque<DoubleArray>()
        var seen = false
        var miss = 0
    }

    private val hist = ArrayDeque<DoubleArray>()
    var direction = 0
    private var omega = C.PAC_OMEGA
    var moving = false
    private val tracks = ArrayList<Track>()

    private fun ang(p: DoubleArray) = Math.toDegrees(atan2(p[1] - C.RING_CY, p[0] - C.RING_CX))

    fun update(t: Double, det: Detection): World {
        var pacA: Double? = null
        val p = det.pac
        if (p != null) {
            var a = ang(p)
            if (hist.isNotEmpty()) {
                val last = hist.last()[1]
                a = last + wrap(a - last)
            }
            hist.addLast(doubleArrayOf(t, a))
            if (hist.size > 12) hist.removeFirst()
            pacA = a
            estimate()
        }
        val o = det.orb
        val orbA = if (o != null) ang(o) else null
        val bars = trackBars(t, det.bars)
        return World(t, if (pacA != null) wrap(pacA) else null, direction, omega, orbA, bars, moving)
    }

    private fun estimate() {
        if (hist.size < 4) return
        val pts = hist.toList().takeLast(6)
        val dt = pts.last()[0] - pts.first()[0]
        if (dt < 0.05) return
        val w = (pts.last()[1] - pts.first()[1]) / dt
        moving = abs(w) > 30
        if (moving) {
            direction = if (w > 0) 1 else -1
            if (abs(w) > 60 && abs(w) < 180) omega = 0.9 * omega + 0.1 * abs(w)
        }
    }

    private fun trackBars(t: Double, obs: List<DoubleArray>): List<Bar> {
        for (tr in tracks) tr.seen = false
        for (o in obs) {
            val x = o[0]
            val y = o[1]
            var best: Track? = null
            var bd = 1e9
            for (tr in tracks) {
                if (tr.seen || abs(tr.x - x) > 45) continue
                val l = tr.hist.last()
                val pred = l[1] + C.BAR_VY * (t - l[0])
                val d = abs(pred - y)
                if (d < 70 && d < bd) { best = tr; bd = d }
            }
            if (best == null) { best = Track(x); tracks.add(best) }
            best.x = 0.7 * best.x + 0.3 * x
            best.hist.addLast(doubleArrayOf(t, y))
            if (best.hist.size > 8) best.hist.removeFirst()
            best.seen = true
            best.miss = 0
        }
        for (tr in tracks) if (!tr.seen) tr.miss++
        tracks.removeAll { it.miss >= 6 }
        val out = ArrayList<Bar>()
        for (tr in tracks) {
            if (!tr.seen) continue
            val h = tr.hist
            var vy = C.BAR_VY
            if (h.size >= 4) {
                val v = (h.last()[1] - h.first()[1]) / maxOf(h.last()[0] - h.first()[0], 1e-3)
                if (v > 100 && v < 500) vy = v
            }
            out.add(Bar(tr.x, h.last()[1], vy))
        }
        return out
    }
}
