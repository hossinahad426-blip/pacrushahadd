"""Colour-agnostic detection. The game recolours the player and the spikes
constantly, so we NEVER classify by colour: we subtract a static background
and classify blobs by SIZE and SHAPE (bar = wide, pac = ~70px, orb = ~46px)."""
import math
import cv2
import numpy as np
from dataclasses import dataclass
from .config import Config, REF_W


@dataclass
class Detection:
    in_game: bool
    pac: tuple | None          # (x, y) in ref px
    orb: tuple | None
    bars: list                 # [(cx, cy)] bar centres in ref px


class Vision:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.bg = None
        self._k = np.ones((5, 5), np.uint8)
        self._hist = []
        self._last_hist = 0.0

    # ---------- background ----------
    def set_background(self, frames):
        self.bg = np.median(np.stack([self._norm(f) for f in frames]), axis=0).astype(np.uint8)

    def save_background(self, path=None):
        np.save(path or self.cfg.background_path, self.bg)

    def load_background(self, path=None):
        p = path or self.cfg.background_path
        try:
            self.bg = np.load(p)
            return True
        except OSError:
            return False

    def _norm(self, frame):
        h, w = frame.shape[:2]
        s = REF_W / w
        return cv2.resize(frame, (REF_W, int(round(h * s))), interpolation=cv2.INTER_AREA)

    # ---------- main ----------
    def process(self, frame) -> Detection:
        img = self._norm(frame)
        if self.bg is None or self.bg.shape != img.shape:
            raise RuntimeError("No background. Run tools/calibrate.py first.")
        c = self.cfg
        diff = cv2.absdiff(img, self.bg).max(axis=2)
        in_game = self._in_game(diff)
        if not in_game:
            return Detection(False, None, None, [])
        n, st, cen = self.components(img, diff)
        pac = orb = None
        bars = []
        H = img.shape[0]
        for i in range(1, n):
            x, y, w, h, a = st[i]
            if a < 120:
                continue
            cx, cy = float(cen[i][0]), float(cen[i][1])
            if w >= c.bar_min_w and h <= c.bar_max_h and w / max(h, 1) > 2.0:
                # bars clipped by the top/bottom edge: rebuild centre from the visible edge
                if y <= 1 and h < c.bar_h - 3:
                    cy = (y + h) - c.bar_h / 2
                elif y + h >= H - 1 and h < c.bar_h - 3:
                    cy = y + c.bar_h / 2
                bars.append((cx, cy))
            elif c.pac_size[0] <= w <= c.pac_size[1] and c.pac_size[0] <= h <= c.pac_size[1]:
                if self._near_ring(cx, cy):
                    pac = (cx, cy)
            elif c.orb_size[0] <= w <= c.orb_size[1] and c.orb_size[0] <= h <= c.orb_size[1]:
                if self._near_ring(cx, cy):
                    orb = (cx, cy)
        return Detection(True, pac, orb, bars)

    def components(self, img, diff=None):
        c = self.cfg
        if diff is None:
            diff = cv2.absdiff(img, self.bg).max(axis=2)
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        m = ((diff > c.diff_thresh) & (hsv[..., 1] > c.sat_min) & (hsv[..., 2] > c.val_min))
        m = cv2.morphologyEx(m.astype(np.uint8) * 255, cv2.MORPH_CLOSE, self._k)
        n, _, st, cen = cv2.connectedComponentsWithStats(m)
        return n, st, cen

    def _near_ring(self, x, y):
        c = self.cfg
        return abs(math.hypot(x - c.ring_cx, y - c.ring_cy) - c.ring_r) < 40

    def _in_game(self, diff):
        """Menu and game-over screens differ hugely from the in-game background."""
        c = self.cfg
        yy, xx = np.ogrid[:diff.shape[0], :diff.shape[1]]
        d = np.hypot(xx - c.ring_cx, yy - c.ring_cy)
        ring = (d > c.ring_r - 50) & (d < c.ring_r + 50)
        return float(np.median(diff[ring])) < 18
