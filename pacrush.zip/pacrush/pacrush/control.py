import subprocess, time


class DryInput:
    def __init__(self, *a, **k): pass
    def tap(self, fx, fy): print(f"[dry] tap {fx:.2f},{fy:.2f}")


class AdbInput:
    """Persistent `adb shell` so each tap costs one pipe write instead of a new process."""
    def __init__(self, cfg, size=None):
        cmd = ["adb"] + (["-s", cfg.adb_serial] if cfg.adb_serial else []) + ["shell"]
        self.p = subprocess.Popen(cmd, stdin=subprocess.PIPE, bufsize=0)
        if size is None:
            out = subprocess.run(cmd[:-1] + ["shell", "wm", "size"], capture_output=True, text=True).stdout
            size = tuple(int(v) for v in out.strip().split()[-1].split("x"))
        self.w, self.h = size

    def tap(self, fx, fy):
        self.p.stdin.write(f"input tap {int(fx*self.w)} {int(fy*self.h)}\n".encode())


class MouseInput:
    """Click inside an emulator window at the same relative position."""
    def __init__(self, cfg):
        from pynput.mouse import Controller, Button
        self.m, self.b = Controller(), Button.left
        self.l, self.t, self.w, self.h = cfg.window_region

    def tap(self, fx, fy):
        old = self.m.position
        self.m.position = (self.l + fx * self.w, self.t + fy * self.h)
        self.m.click(self.b)
        self.m.position = old


def make_input(cfg):
    return {"adb": AdbInput, "mouse": MouseInput, "dry": DryInput}[cfg.input](cfg)
