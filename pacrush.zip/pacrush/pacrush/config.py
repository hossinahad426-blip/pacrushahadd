"""All tunables live here. Lengths are in 'reference pixels' (frame width = 720)
and are scaled automatically to the real capture width."""
from dataclasses import dataclass, field
import json, os

REF_W, REF_H = 720, 1600


@dataclass
class Config:
    # ---- geometry (measured from a 720x1600 recording) ----
    ring_cx: float = 359.8        # ring centre x
    ring_cy: float = 847.4        # ring centre y
    ring_r: float = 185.3         # radius the player travels on
    # ---- object sizes ----
    bar_w: float = 126.0          # spiked bar (incl. spikes)
    bar_h: float = 41.0
    pac_hit_r: float = 29.0       # hit radius used for collision tests (visual ~35)
    safety_margin: float = 9.0    # extra clearance in ref px
    # ---- physics (defaults; refined online) ----
    pac_omega_deg: float = 105.0  # deg/s along the ring
    bar_vy: float = 250.0         # px/s downward
    # ---- detection size windows (ref px) ----
    pac_size: tuple = (58, 84)
    orb_size: tuple = (38, 57)
    bar_min_w: float = 100.0
    bar_max_h: float = 62.0
    diff_thresh: int = 60
    sat_min: int = 70
    val_min: int = 90
    # ---- control ----
    tap_latency: float = 0.10     # s between tap command and the game reacting
    min_tap_gap: float = 0.12     # never tap faster than this
    horizon: float = 2.0          # planning horizon (s)
    sim_dt: float = 0.025
    orb_tol_deg: float = 15.0
    # ---- screens (fractions of frame) ----
    tap_point: tuple = (0.50, 0.55)       # point tapped to leave the menu / start
    restart_point: tuple = (0.35, 0.74)   # "replay" button on game-over panel
    # ---- capture ----
    capture: str = "window"       # window | adb | video
    window_region: tuple = (0, 0, 720, 1600)  # left, top, width, height on screen
    target_fps: int = 60
    # ---- input ----
    input: str = "adb"            # adb | mouse | dry
    adb_serial: str = ""
    # ---- misc ----
    background_path: str = "background.npy"
    log_dir: str = "logs"
    debug_window: bool = True

    @classmethod
    def load(cls, path="config.json"):
        c = cls()
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                for k, v in json.load(f).items():
                    if hasattr(c, k):
                        setattr(c, k, tuple(v) if isinstance(v, list) else v)
        return c

    def save(self, path="config.json"):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.__dict__, f, indent=2)
