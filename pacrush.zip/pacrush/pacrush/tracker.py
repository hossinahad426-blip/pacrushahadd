"""Turns raw per-frame detections into motion estimates:
pac angle / direction / angular speed, bar velocities, orb angle."""
import math
from collections import deque
from dataclasses import dataclass
from .config import Config


def wrap(a):
    return (a + 180.0) % 360.0 - 180.0


@dataclass
class Bar:
    x: float
    y: float
    vy: float


@dataclass
class World:
    t: float
    pac_angle: float | None     # degrees, screen coords (y down)
    direction: int              # +1 / -1 (0 = unknown / standing still)
    omega: float                # deg/s magnitude
    orb_angle: float | None
    bars: list
    moving: bool


class Tracker:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.hist = deque(maxlen=12)       # (t, unwrapped angle)
        self.direction = 0
        self.omega = cfg.pac_omega_deg
        self.tracks = []                   # each: dict(x, hist=deque[(t,y)])
        self.moving = False

    def _angle(self, p):
        return math.degrees(math.atan2(p[1] - self.cfg.ring_cy, p[0] - self.cfg.ring_cx))

    def update(self, t, det) -> World:
        pac_a = None
        if det.pac is not None:
            a = self._angle(det.pac)
            if self.hist:
                a = self.hist[-1][1] + wrap(a - self.hist[-1][1])   # unwrap
            self.hist.append((t, a))
            pac_a = a
            self._estimate_motion()
        orb_a = self._angle(det.orb) if det.orb is not None else None
        bars = self._track_bars(t, det.bars)
        return World(t, None if pac_a is None else wrap(pac_a), self.direction,
                     self.omega, orb_a, bars, self.moving)

    def _estimate_motion(self):
        if len(self.hist) < 4:
            return
        pts = list(self.hist)[-6:]
        dt = pts[-1][0] - pts[0][0]
        if dt < 0.05:
            return
        w = (pts[-1][1] - pts[0][1]) / dt
        self.moving = abs(w) > 30
        if self.moving:
            self.direction = 1 if w > 0 else -1
            if 60 < abs(w) < 180:        # sane range; smooth it
                self.omega = 0.9 * self.omega + 0.1 * abs(w)

    def _track_bars(self, t, obs):
        for tr in self.tracks:
            tr["seen"] = False
        for (x, y) in obs:
            best, bd = None, 1e9
            for tr in self.tracks:
                if tr["seen"] or abs(tr["x"] - x) > 45:
                    continue
                ly = tr["hist"][-1][1]
                pred = ly + self.cfg.bar_vy * (t - tr["hist"][-1][0])
                d = abs(pred - y)
                if d < 70 and d < bd:
                    best, bd = tr, d
            if best is None:
                best = {"x": x, "hist": deque(maxlen=8), "seen": True, "miss": 0}
                self.tracks.append(best)
            best["x"] = 0.7 * best["x"] + 0.3 * x
            best["hist"].append((t, y))
            best["seen"] = True
            best["miss"] = 0
        keep = []
        for tr in self.tracks:
            if not tr["seen"]:
                tr["miss"] += 1
            if tr["miss"] < 6:
                keep.append(tr)
        self.tracks = keep
        out = []
        for tr in self.tracks:
            if not tr["seen"]:
                continue
            h = tr["hist"]
            vy = self.cfg.bar_vy
            if len(h) >= 4:
                v = (h[-1][1] - h[0][1]) / max(h[-1][0] - h[0][0], 1e-3)
                if 100 < v < 500:
                    vy = v
            out.append(Bar(tr["x"], h[-1][1], vy))
        return out
