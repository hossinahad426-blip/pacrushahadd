import json, os, time
from collections import deque
import cv2
from .config import Config
from .vision import Vision
from .tracker import Tracker
from .planner import Planner
from .capture import WindowCapture, AdbCapture
from .control import make_input


class Bot:
    def __init__(self, cfg: Config, capture=None, inp=None):
        self.cfg = cfg
        self.vision = Vision(cfg)
        if not self.vision.load_background():
            raise SystemExit("background.npy missing - run: python -m tools.calibrate record")
        self.tracker = Tracker(cfg)
        self.planner = Planner(cfg)
        self.cap = capture or (WindowCapture(cfg.window_region) if cfg.capture == "window"
                               else AdbCapture(cfg.adb_serial))
        self.inp = inp or make_input(cfg)
        self.reset()
        self.trace = deque(maxlen=120)         # last ~2-4 s, dumped on death
        os.makedirs(cfg.log_dir, exist_ok=True)

    def reset(self):
        self.tracker = Tracker(self.cfg)
        self.pending = []                      # [apply_time, direction_when_tapped]
        self.last_tap = -9.0
        self.game_t0 = None
        self.was_in_game = False
        self.menu_tap_t = -9.0
        self.menu_toggle = 0
        self.games = 0

    def tap(self, t):
        p = self.cfg.tap_point
        self.inp.tap(*p)
        self.last_tap = t
        self.pending.append([t + self.cfg.tap_latency, self.tracker.direction])

    def step(self, t, frame):
        c = self.cfg
        det = self.vision.process(frame)
        if not det.in_game:
            if self.was_in_game:
                self.dump_death(t)
                self.reset()
            if t - self.menu_tap_t > 1.0:                       # menu / game-over: alternate buttons
                self.inp.tap(*(c.restart_point if self.menu_toggle % 2 == 0 else c.tap_point))
                self.menu_toggle += 1
                self.menu_tap_t = t
            return det, None, None
        if not self.was_in_game:
            self.was_in_game, self.game_t0 = True, t
            self.games += 1
        w = self.tracker.update(t, det)
        # drop confirmed / expired taps
        self.pending = [p for p in self.pending
                        if t < p[0] + 0.5 and not (t > p[0] + 0.05 and w.moving and w.direction != p[1] and p[1] != 0)]
        info = {}
        if w.pac_angle is not None:
            if not w.moving and not w.bars and t - self.game_t0 > 0.5 and t - self.last_tap > 1.0:
                self.tap(t)                                      # pac waits for the first tap
                info = {"why": "start"}
            else:
                tap, info = self.planner.plan(w, t - self.last_tap, [max(p[0] - t, 0) for p in self.pending])
                if tap:
                    self.tap(t)
        self.trace.append({"t": round(t, 3), "ang": w.pac_angle, "dir": w.direction, "orb": w.orb_angle,
                           "bars": [(round(b.x), round(b.y), round(b.vy)) for b in w.bars],
                           "plan": info.get("plan"), "surv": info.get("surv"), "tap_t": self.last_tap})
        return det, w, info

    def dump_death(self, t):
        path = os.path.join(self.cfg.log_dir, f"death_{int(time.time())}.json")
        with open(path, "w") as f:
            json.dump(list(self.trace), f)
        print(f"[game {self.games}] ended. trace -> {path}")

    def draw(self, frame, det, w, info):
        s = 720 / frame.shape[1]
        vis = cv2.resize(frame, None, fx=s, fy=s)
        c = self.cfg
        cv2.circle(vis, (int(c.ring_cx), int(c.ring_cy)), int(c.ring_r), (255, 255, 0), 1)
        if det.pac: cv2.circle(vis, tuple(map(int, det.pac)), 34, (0, 255, 0), 2)
        if det.orb: cv2.circle(vis, tuple(map(int, det.orb)), 26, (255, 0, 255), 2)
        for (x, y) in det.bars:
            cv2.rectangle(vis, (int(x - c.bar_w / 2), int(y - c.bar_h / 2)), (int(x + c.bar_w / 2), int(y + c.bar_h / 2)), (0, 0, 255), 2)
        if info:
            cv2.putText(vis, str(info.get("plan")), (10, 60), 0, 0.9, (255, 255, 255), 2)
        return cv2.resize(vis, None, fx=0.5, fy=0.5)

    def run(self):
        print("running - press q in the debug window or Ctrl+C to stop")
        n, t0 = 0, time.perf_counter()
        while True:
            t, frame = self.cap.grab()
            det, w, info = self.step(t, frame)
            n += 1
            if self.cfg.debug_window:
                cv2.imshow("pacrush", self.draw(frame, det, w, info))
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
            if n % 300 == 0:
                print(f"{n / (time.perf_counter() - t0):.0f} fps")
