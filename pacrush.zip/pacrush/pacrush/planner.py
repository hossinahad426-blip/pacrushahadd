"""Look-ahead planner.
Builds a (time x angle) danger map from every bar's predicted position, then
scores a family of tap plans (no tap, 1 tap, 2 taps at any time) and picks the
safest one that also reaches the orb fastest. Re-planned every frame, so it can
change its mind when a second bar appears (the old bot's weak point)."""
import math
import numpy as np
from .config import Config

NA = 720                      # angle resolution = 0.5 deg


class Planner:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.dt = 0.04
        self.T = int(cfg.horizon / self.dt)
        self.ang = np.arange(NA) * (360.0 / NA) - 180.0
        r = cfg.ring_r
        self.px = cfg.ring_cx + r * np.cos(np.radians(self.ang))
        self.py = cfg.ring_cy + r * np.sin(np.radians(self.ang))
        # plan table: flip step indices
        self.min_gap = max(2, int(cfg.min_tap_gap / self.dt))
        self.lat = int(math.ceil(cfg.tap_latency / self.dt))
        steps = list(range(self.lat, self.T))
        self.plans = [()] + [(i,) for i in steps]
        for i in steps[::1]:
            for j in steps:
                if j >= i + self.min_gap:
                    self.plans.append((i, j))
        P = len(self.plans)
        flip = np.zeros((P, self.T), np.int8)
        for p, fl in enumerate(self.plans):
            for f in fl:
                flip[p, f:] ^= 1
        self.sign = 1 - 2 * flip.astype(np.int8)           # +1 / -1 multiplier
        self.nflips = np.array([len(f) for f in self.plans])
        self.first_flip = np.array([f[0] if f else 10**6 for f in self.plans])
        self.t_idx = np.arange(1, self.T + 1)

    def _danger(self, bars, margin):
        c = self.cfg
        D = np.zeros((self.T, NA), bool)
        rr = c.pac_hit_r + margin
        hw, hh = c.bar_w / 2, c.bar_h / 2
        for k in range(self.T):
            t = (k + 1) * self.dt
            for b in bars:
                by = b.y + b.vy * t
                if by < -80 or by > 1700:
                    continue
                dx = np.maximum(np.abs(self.px - b.x) - hw, 0)
                dy = np.maximum(np.abs(self.py - by) - hh, 0)
                D[k] |= (dx * dx + dy * dy) < rr * rr
        return D

    def plan(self, w, now_since_last_tap=9.0, pending=()):
        """Returns (tap_now: bool, info dict)."""
        c = self.cfg
        if w.pac_angle is None:
            return False, {"why": "no pac"}
        d0 = w.direction if w.direction != 0 else 1
        om = w.omega
        # angle path for every plan
        step = om * self.dt
        base = np.ones(self.T, np.int8)           # taps already sent but not yet applied
        for r in pending:
            base[max(0, int(round(r / self.dt))):] *= -1
        sign = self.sign * base[None, :]
        path = w.pac_angle + d0 * step * np.cumsum(sign, axis=1)          # (P,T)
        idx = np.round((((path + 180.0) % 360.0) / (360.0 / NA))).astype(int) % NA
        ks = np.arange(self.T)[None, :]
        strict = self._danger(w.bars, c.safety_margin)
        loose = self._danger(w.bars, 0.0)

        def surv(D):
            hit = D[ks, idx]                                  # (P,T)
            first = np.where(hit.any(axis=1), hit.argmax(axis=1), self.T)
            return first * self.dt

        s_str, s_loo = surv(strict), surv(loose)
        # orb cost
        if w.orb_angle is not None:
            diff = np.abs(((path - w.orb_angle + 180.0) % 360.0) - 180.0)
            reach = diff < c.orb_tol_deg
            tfirst = np.where(reach.any(axis=1), reach.argmax(axis=1) * self.dt, self.T * self.dt +
                              diff[:, -1] / max(om, 1.0))
        else:
            tfirst = np.zeros(len(self.plans))
        H = self.T * self.dt
        safe = (s_loo >= H) & (s_str >= H)
        score = 100 * s_loo + 40 * s_str - 0.6 * self.nflips
        score = score - np.where(safe, 3.0, 0.1) * tfirst
        # a tap can't be issued before min_tap_gap has elapsed since the previous one
        need = int(math.ceil(max(0.0, c.min_tap_gap - now_since_last_tap) / self.dt))
        if need > 0:
            score = np.where(self.first_flip - self.lat >= need, score, -1e9)
            score[0] = max(score[0], -1e8)             # 'no tap' always allowed
        best = int(np.argmax(score))
        fl = self.plans[best]
        tap = bool(fl) and fl[0] <= self.lat + 1 and now_since_last_tap >= c.min_tap_gap
        return tap, {"plan": fl, "surv": float(s_loo[best]), "strict": float(s_str[best]),
                     "safe": bool(safe[best]), "noflip_surv": float(s_loo[0])}
