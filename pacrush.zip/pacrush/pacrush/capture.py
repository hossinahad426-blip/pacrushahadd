import subprocess, time
import cv2
import numpy as np


class WindowCapture:
    """Grabs a screen region (an emulator window or a scrcpy mirror window). Fast (60+ fps)."""
    def __init__(self, region):
        import mss
        self.sct = mss.mss()
        l, t, w, h = region
        self.mon = {"left": int(l), "top": int(t), "width": int(w), "height": int(h)}

    def grab(self):
        img = np.asarray(self.sct.grab(self.mon))
        return time.perf_counter(), cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)


class AdbCapture:
    """Fallback: adb screencap. Usually 4-8 fps, too slow for high scores."""
    def __init__(self, serial=""):
        self.cmd = ["adb"] + (["-s", serial] if serial else []) + ["exec-out", "screencap", "-p"]

    def grab(self):
        raw = subprocess.run(self.cmd, capture_output=True, check=True).stdout
        return time.perf_counter(), cv2.imdecode(np.frombuffer(raw, np.uint8), cv2.IMREAD_COLOR)


class VideoCapture:
    """Offline: replay a screen recording (used by tools/analyze_video.py)."""
    def __init__(self, path, start=0.0, end=1e9):
        self.cap = cv2.VideoCapture(path)
        self.cap.set(cv2.CAP_PROP_POS_MSEC, start * 1000)
        self.end = end

    def grab(self):
        ok, f = self.cap.read()
        t = self.cap.get(cv2.CAP_PROP_POS_MSEC) / 1000.0
        if not ok or t > self.end:
            raise EOFError
        return t, f
