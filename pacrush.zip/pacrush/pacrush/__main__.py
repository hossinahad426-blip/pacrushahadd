from .config import Config
from .bot import Bot

if __name__ == "__main__":
    Bot(Config.load()).run()
