"""Replay a screen recording through the full pipeline (no taps are sent).
Writes an overlay video and prints detection statistics + where the bot WOULD tap.
  python -m tools.analyze_video rec.mp4 --start 4.6 --end 19 --out overlay.mp4"""
import argparse
from collections import Counter
import cv2
from pacrush.config import Config
from pacrush.bot import Bot
from pacrush.capture import VideoCapture


class Null:
    taps = []
    def tap(self, fx, fy): pass


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("video"); ap.add_argument("--start", type=float, default=0)
    ap.add_argument("--end", type=float, default=1e9); ap.add_argument("--out", default="")
    a = ap.parse_args()
    cfg = Config.load(); cfg.debug_window = False
    bot = Bot(cfg, capture=VideoCapture(a.video, a.start, a.end), inp=Null())
    wr, stats, taps, n = None, Counter(), [], 0
    while True:
        try:
            t, f = bot.cap.grab()
        except EOFError:
            break
        det, w, info = bot.step(t, f)
        n += 1
        stats["in_game"] += det.in_game
        stats["pac_found"] += det.pac is not None
        stats["orb_found"] += det.orb is not None
        stats[f"bars={len(det.bars)}"] += det.in_game
        if info and info.get("plan") and info["plan"][0] <= bot.planner.lat + 1 and bot.last_tap == t:
            taps.append(round(t, 2))
        if a.out and det.in_game:
            o = bot.draw(f, det, w, info)
            if wr is None:
                wr = cv2.VideoWriter(a.out, cv2.VideoWriter_fourcc(*"mp4v"), 30, (o.shape[1], o.shape[0]))
            wr.write(o)
    print(f"{n} frames:", dict(stats))
    print("NOTE: open-loop replay - the video keeps the HUMAN's taps, so these planner taps are only a sanity check of timing:", taps[:12], "...")
    if wr: wr.release()
