"""Builds background.npy and fits the ring (centre + radius) from a play session.

  python -m tools.calibrate video my_recording.mp4 --start 4.6 --end 17
  python -m tools.calibrate record --seconds 15      (play manually while it records)

Use a session where the game is running (menu / game-over frames must be excluded).
Needs the player to travel round the ring at least once so the ring can be fitted."""
import argparse, math, time
import cv2, numpy as np
from pacrush.config import Config
from pacrush.vision import Vision
from pacrush.capture import VideoCapture, WindowCapture


def collect(cap, seconds, every=0.1):
    frames, last, t0 = [], -9, None
    while True:
        try:
            t, f = cap.grab()
        except EOFError:
            break
        t0 = t if t0 is None else t0
        if t - t0 > seconds:
            break
        if t - last >= every:
            frames.append(f); last = t
    return frames


def fit_circle(P):
    P = np.array(P, float)
    for _ in range(8):
        A = np.c_[2 * P[:, 0], 2 * P[:, 1], np.ones(len(P))]
        cx, cy, k = np.linalg.lstsq(A, (P ** 2).sum(1), rcond=None)[0]
        r = math.sqrt(k + cx * cx + cy * cy)
        res = np.abs(np.hypot(P[:, 0] - cx, P[:, 1] - cy) - r)
        P = P[res < max(6, 2 * res.std())] if len(P) > 20 else P
    return cx, cy, r, float(res.std()), len(P)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["video", "record"])
    ap.add_argument("path", nargs="?")
    ap.add_argument("--start", type=float, default=0)
    ap.add_argument("--end", type=float, default=1e9)
    ap.add_argument("--seconds", type=float, default=15)
    a = ap.parse_args()
    cfg = Config.load()
    cap = VideoCapture(a.path, a.start, a.end) if a.mode == "video" else WindowCapture(cfg.window_region)
    frames = collect(cap, a.end - a.start if a.mode == "video" else a.seconds)
    print(f"{len(frames)} frames")
    v = Vision(cfg)
    v.set_background(frames[::3])
    pts = []
    for f in frames:
        img = v._norm(f)
        n, st, cen = v.components(img)
        for i in range(1, n):
            x, y, w, h, ar = st[i]
            if cfg.pac_size[0] + 4 <= w <= cfg.pac_size[1] - 6 and abs(w - h) < 8:
                pts.append(cen[i])
    if len(pts) < 30:
        raise SystemExit("not enough player detections - record a longer in-game session")
    cx, cy, r, sd, n = fit_circle(pts)
    print(f"ring fit: centre=({cx:.1f},{cy:.1f}) radius={r:.1f} (residual {sd:.2f}px, {n} pts)")
    if sd > 4:
        print("WARNING: poor fit - check the recording only contains in-game frames")
    cfg.ring_cx, cfg.ring_cy, cfg.ring_r = round(cx, 1), round(cy, 1), round(r, 1)
    v.save_background(cfg.background_path)
    cfg.save()
    print("saved background.npy + config.json")
