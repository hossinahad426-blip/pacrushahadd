"""Closed-loop simulator using the physics measured from the recording.
Checks the planner survives, without needing a phone. Run: python -m tests.sim"""
import math, random, sys, time
from pacrush.config import Config
from pacrush.planner import Planner
from pacrush.tracker import World, Bar, wrap


def episode(cfg, planner, seed, max_t=120.0, fps=30, hard=False):
    rnd = random.Random(seed)
    dt = 1 / fps
    ang, d, om = 0.0, 1, cfg.pac_omega_deg
    bars, t, nxt, score, last_tap = [], 0.0, 1.0, 0, -9
    pending = []                              # taps in flight (apply at time)
    orb = rnd.uniform(-180, 180)
    lanes = [120, 360, 600]
    while t < max_t:
        if t >= nxt:
            lane = rnd.choice(lanes)
            bars.append([lane + rnd.uniform(-3, 3), -30.0])
            if hard and rnd.random() < 0.5:
                bars.append([rnd.choice(lanes), -30.0 - rnd.uniform(0, 250)])
            nxt = t + (rnd.uniform(0.8, 1.6) if hard else rnd.uniform(1.0, 2.0))
        for b in bars:
            b[1] += cfg.bar_vy * dt
        bars = [b for b in bars if b[1] < 1700]
        pending = [p for p in pending if p > t or (d := -d) and False]
        for p in list(pending):
            if p <= t:
                d = -d; pending.remove(p)
        ang = wrap(ang + d * om * dt)
        if abs(wrap(ang - orb)) < 12:
            score += 10; orb = rnd.uniform(-180, 180)
        # collision with real hit radius
        px = cfg.ring_cx + cfg.ring_r * math.cos(math.radians(ang))
        py = cfg.ring_cy + cfg.ring_r * math.sin(math.radians(ang))
        for b in bars:
            dx = max(abs(px - b[0]) - cfg.bar_w / 2, 0); dy = max(abs(py - b[1]) - cfg.bar_h / 2, 0)
            if math.hypot(dx, dy) < cfg.pac_hit_r:
                return t, score
        vis = [Bar(b[0], b[1], cfg.bar_vy) for b in bars if -20 < b[1] < 1650]
        w = World(t, ang, d, om, orb, vis, True)
        tap, _ = planner.plan(w, t - last_tap, [p - t for p in pending])
        if tap:
            pending.append(t + cfg.tap_latency); last_tap = t
        t += dt
    return t, score


if __name__ == "__main__":
    cfg = Config(); pl = Planner(cfg)
    hard = "--hard" in sys.argv
    res = []
    t0 = time.time()
    for s in range(int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 10):
        tt, sc = episode(cfg, pl, s, hard=hard)
        res.append(tt); print(f"seed {s}: survived {tt:6.1f}s score {sc}")
    print(f"mean {sum(res)/len(res):.1f}s  min {min(res):.1f}s  ({time.time()-t0:.0f}s wall)")
